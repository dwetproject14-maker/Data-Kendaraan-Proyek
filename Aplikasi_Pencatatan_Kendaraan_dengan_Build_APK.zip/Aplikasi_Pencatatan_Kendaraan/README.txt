APLIKASI PENCATATAN DATA KENDARAAN

Isi:
- app/src/main/assets/index.html : aplikasi yang bisa langsung dibuka di browser.
- Folder app/ dan file Gradle: proyek Android Studio untuk membangun APK.

Fitur:
- Input, edit, hapus data kendaraan.
- Nomor urut otomatis.
- Penyimpanan lokal pada perangkat.
- Cetak / Simpan sebagai PDF (format A4 landscape).
- Ekspor CSV yang dapat dibuka dengan Microsoft Excel.

MEMBANGUN APK:
1. Ekstrak ZIP ini.
2. Buka folder Aplikasi_Pencatatan_Kendaraan melalui Android Studio.
3. Pastikan Android SDK Platform 35 dan Android Gradle Plugin dapat diunduh.
4. Tunggu proses Gradle Sync selesai.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug akan tersedia di app/build/outputs/apk/debug/app-debug.apk.

CATATAN:
APK belum dikompilasi di paket ini karena lingkungan pembuatan tidak menyediakan Android SDK/Gradle.
Aplikasi web dapat dicoba dengan membuka app/src/main/assets/index.html di browser.
Data tersimpan di penyimpanan browser/aplikasi pada perangkat yang digunakan.
